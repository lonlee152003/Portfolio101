<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Retrieve Input</title>
        <link rel="stylesheet" type="text/css" href="resume.css">
    </head>
    <body>
        <form action='caseStudyResume.php' method='GET'>
        <div class="majordiv">
        <br />
        <br />
        <br /> 
        <br />
        <br />
        <div class='fonta'>
            <div>Resume
                
                <div></div>      
            <div class="id_pos">
        <table class="id_pic">
            <tr>
                <td></td>
            </tr>
        </table>
            </div>
            </div>
            </div>
        
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        
       
        <div class='fontb'>Personal Information</div>
        <table class='tablex'>
            
            <tr>
                <?//personal info?>
                <td class='colxx1'>Last Name: </td><td class='colxx'><div><? echo $_REQUEST['lname']; ?> </div></td>
                <td class='colxx1'>&nbsp;&nbsp;&nbsp;&nbsp;First Name: </td><td class='colxx'><? echo $_REQUEST['fname']; ?></td>
                <td class='colxx1'>Middle Name: </td><td class='colxx'><? echo $_REQUEST['mname']; ?></td>
           
            </tr>
             <tr>
                <td class='colxx1'>Barangay: </td><td class='colxx'><? echo $_REQUEST['bar']; ?></td>
                <td class='colxx1'>&nbsp;&nbsp;&nbsp;&nbsp;City: </td><td class='colxx'><? echo $_REQUEST['cit']; ?></td>
                <td class='colxx1'>Province: </td><td class='colxx'><? echo $_REQUEST['prov']; ?></td>
            </tr>
       
            <tr>
                <td class='colxx1'>Contact Number: </td><td class='colxx'><? echo $_REQUEST['number']; ?></td>
            </tr>
            <tr>
                <td class='colxx1'>Email Address: </td><td class='colxx'><? echo $_REQUEST['emil']; ?></td>   
            </tr>
        </table>
        <table>
            <tr>
                <td class='colxx1a'>Gender: &nbsp;&nbsp;</td>
                <td class='colxx1aa'><? echo $_REQUEST['gender1']; ?></td>
            </tr>
        </table>
        <table>
            <tr>
                <td class="majorfont">Birthday: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </td>
                <td class="majorfont">
                <? echo $_REQUEST['mont']; ?>
                </td>
            
                <td class="majorfont">
                <? echo $_REQUEST['day1']; ?>
                </td>
                <td class="majorfont">
                    <?  echo $_REQUEST['year1'];  ?>
                </td>
            </tr>
            </table>
        <table>
            <tr>
                <td class="majorfont">Citizenship: &nbsp;&nbsp;&nbsp;</td><td class="majorfont"><? echo $_REQUEST['cship']; ?></td>
            </tr>
            <tr>
                <td class="majorfont">Religion: </td>
                <td class="majorfont"><? echo $_REQUEST['relstats']; ?></td>
            </tr>
            <tr>
                <td class="majorfont">Civil Status: </td>
                <td class="majorfont"><? echo $_REQUEST['stats']; ?></td>
            </tr>
            
        </table>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <div class="fontba">Educational Background</div>
            <table border="1px" class="edtable flot1">
                <tr class="majorfont">
            <td class=" textcenter"><div class="ns">LEVEL</div></td>
            <td class=" textcenter">Name of School </td>
            <td class=" textcenter">Address </td>
            <td class=" textcenter">Year Graduated </td>
                </tr>
                <tr class="majorfont">
                    <td>Elementary</td>
                <td><div class="ns1"><? echo $_REQUEST['elemname']; ?></div></td>
                <td><div class="ns1"><? echo $_REQUEST['elemadd']; ?></div></td>
                <td><div class="ns2"><? echo $_REQUEST['elemyr']; ?></div></td>
                </tr>
                <tr class="majorfont">
                    <td>High School </td>
                    <td><div class="ns1"><? echo $_REQUEST['highname']; ?></div></td>
                    <td><div class="ns1"><? echo $_REQUEST['highmadd']; ?></div></td>
                    <td><div class="ns2"><? echo $_REQUEST['highyr']; ?></div></td>
                </tr>
                <tr class="majorfont">
                    <td>College</td>
                    <td><div class="ns1"><? echo $_REQUEST['colname']; ?></div></td>
                    <td><div class="ns1"><? echo $_REQUEST['colmadd']; ?></div></td>
                    <td><div class="ns2"><? echo $_REQUEST['colmyr']; ?></div></td>
                </tr>
                <tr class="majorfont"> 
                   <td>Course</td>
                   <td><div class="ns1"><? echo $_REQUEST['corsname']; ?></div></td>
                </tr>
            </table>
            
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <div class="fontba">Work Experience
        </div>
            <div class="trea majorfont"><blockqoute>
           
                    <? echo $_REQUEST['wexp']; ?>
               
                </blockqoute></div>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
        <div class="fontba">Training and Seminars
        </div>
         <div class="trea majorfont"><blockqoute>
                    <? echo $_REQUEST['sem']; ?>
             </blockqoute></div>
               
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <div class="fontba">Field of Skills
        </div>
        <div class="trea majorfont"><blockqoute>
                    <? echo $_REQUEST['fos']; ?>
             </blockqoute></div>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <div class="fontba">Character Reference
            </div>
            
            <table border="1px" class="flot1">
                <tr class="majorfont textcenter">
                    <td>Name </td>
                    <td>Address </td>
                    <td>Position </td>
                    <td>Contact Number </td>
                </tr>
                <tr class="majorfont">
                    <td><div class="cf1a">1.<? echo $_REQUEST['cr1a']; ?></div></td>
                    <td><div class="cf2a"><? echo $_REQUEST['cr1b']; ?></div></td>
                    <td><div class="cf2a"><? echo $_REQUEST['cr1c']; ?></div></td>
                    <td><div class="cf2a"><? echo $_REQUEST['cr1d']; ?></div></td>
                </tr>
                <tr class="majorfont">
                    <td><div class="cf1a">2.<? echo $_REQUEST['cr2a']; ?></div></td>
                    <td><div class="cf2a"><? echo $_REQUEST['cr2b']; ?></div></td>
                    <td><div class="cf2a"><? echo $_REQUEST['cr2c']; ?></div></td>
                    <td><div class="cf2a"><? echo $_REQUEST['cr2d']; ?></div></td>
                </tr>
                <tr class="majorfont">
                    <td><div class="cf1a">3.<? echo $_REQUEST['cr3a']; ?></div></td>
                    <td><div class="cf2a"><? echo $_REQUEST['cr3b']; ?></div></td>
                    <td><div class="cf2a"><? echo $_REQUEST['cr3c']; ?></div></td>
                    <td><div class="cf2a"><? echo $_REQUEST['cr3d']; ?></div></td>
                </tr>
            </table>
        
         <?
        echo "<form action='caseStudyResume.php' method='POST'>\n
        <input class='majorfont buttonsize' type='submit' value='Back'>\n";
        ?>
        
        
            <div class='bac'>
                <div class='bac1'></div>
                <div class='reserv majorfont'>All Rights Reserved.2014 <br />Powered by: XAMPP <br /> Ronald S.Domingo <br />BSIT-3</div>
                <div class='bacA'></div>
            </div>
        </div>
            </form>
    </body>
</html>
