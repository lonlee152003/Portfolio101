<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Resume Form</title>
        <link rel="stylesheet" type="text/css" href="resume.css">
    </head>
    <body>
         <form action='viewResume.php' method='GET'>
             
             <div class="majordiv">
        <br />
        <br />
        <br /> 
        <br />
        <br />
            <div class='fonta'>
            <div>Resume
                
                <div></div>      
                <div class="id_pos">
                <table class="id_pic">
                     <tr>
                       <td></td>
                     </tr>
                </table>
            </div>
            </div>
            </div>
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <div class='fontb'>Personal Information</div>
        <table class="tablex">
         
            <tr>
                <?//personal info?>
                <td class="colxx1">Last Name: </td><td><? echo "<input  class='colxx' type='text' name='lname' maxlength='30' size='30'>"; ?></td>
                <td class="colxx1">First Name: </td><td><? echo "<input  class='colxx' type='text' name='fname' maxlength='30' size='30'>"; ?></td>
                <td class="colxx1">Middle Name: </td><td><? echo "<input  class='colxx' type='text' name='mname' maxlength='30' size='30'>"; ?></td>
                
            </tr>
             <tr>
                <td class="colxx1">Barangay: </td><td><? echo "<input class='colxx' type='text' name='bar' maxlength='30' size='30'>"; ?></td>
                <td class="colxx1">City: </td><td><? echo "<input class='colxx' type='text' name='cit' maxlength='30' size='30'>"; ?></td>
                <td class="colxx1">Province: </td><td><? echo "<input class='colxx' type='text' name='prov' maxlength='30' size='30'>"; ?></td>
            </tr>
       
            <tr>
                <td class='colxx1'>Contact Number: </td><td><? echo "<input class='colxx' type='text' name='number' maxlength='11' size='30'>"; ?></td>
            </tr>
            <tr>
                <td class='colxx1'>Email Address: </td><td><? echo "<input class='colxx' type='text' name='emil' maxlength='50' size='30'>"; ?></td>   
            </tr>
        </table>
        <table>
            <tr>
                <td class='colxx1a'>Gender: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td class='colxx1aaa'><? echo "<input type='radio' name='gender1' value='Male'>Male";?></td>
                <td class='colxx1aaa'><? echo "<input type='radio' name='gender1' value='Female'>Female";?></td>
            </tr>
        </table>
        <table>
            <tr class="majorfont">
                <td>Birthday: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <? echo "<select class='majorfont' name='mont'>
                        <option>January</option>
                        <option>February</option>
                        <option>March</option>
                        <option>April</option>
                        <option>May</option>
                        <option>June</option>
                        <option>July</option>
                        <option>August</option>
                        <option>September</option>
                        <option>October</option>
                        <option>November</option>
                        <option>December</option>
                    </select>"; ?>
                </td>
            
                <td>
                <?
                    echo "<select class='majorfont' name='day1'>\n";
                    for ($day=1;$day<=31;$day++)
                    {
                    echo " <option value=$day";
                    if ($date1 == $day )
                    {
                    echo " selected";
                    }
                    echo "> $day\n";
                    }
                    echo "</select>\n";
                    
                 ?>
                </td>
                <td>
                    <?
                    echo "<select class='majorfont' class='wid' name='year1'>\n";
                    for ($yr=1985;$yr<=2014;$yr++)
                    {
                    echo " <option value=$yr";
                    if ($yr1 == $yr )
                    {
                    echo " selected";
                    }
                    echo "> $yr\n";
                    }
                    echo "</select>\n";
                    
                 ?>
                </td>
            </tr>
            </table>
        <table>
            <tr class='majorfont'>
                <td>Citizenship: &nbsp;</td><td><? echo "<input  class='majorfont colxx' type='text' name='cship' size='30' maxlength='20'>"; ?></td>
            </tr>
            <tr class='majorfont'>
                <td>Religion: </td>
                <td><? echo"<select class='wid1 colxx' name='relstats'>
                            <option>Roman Catholic</option>
                            <option>Iglisia Ni Cristo</option>
                            <option>Baptist</option>
                            <option>PBMA</option>
                            <option>atheist</option>
                            </select>
                            "; ?></td>
            </tr>
             <tr class='majorfont'>
                
                <td>Civil Status: </td>
                <td><? echo"<select class='wid1 colxx' name='stats'>
                            <option>Single</option>
                            <option>Married</option>
                            <option>Widowed</option>
                            <option>Divorced</option>
                            <option>Separated</option>
                            </select>
                            "; ?></td>
            </tr>

        </table>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <div class="fontba">Educational Backgroud </div>
            <table border="1px"  class="edtable edtable1 flot1">
                <tr class="majorfont">
                    <td class=" textcenter"><div class="ns">LEVEL</div></td>
                    <td class=" textcenter">Name of School: </td>
                    <td class=" textcenter">Address: </td>
                    <td class=" textcenter">Year Graduated: </td>
                </tr>
                <tr>
                    <td class="majorfont">Elementary:</td>
                     <td><? echo "<input class='ns1 majorfont'  type='text' name='elemname' maxlength='100' size='25'>"; ?></td>
                    <td><? echo "<input class='ns1 majorfont' type='text' name='elemadd' maxlength='100' size='25'>"; ?></td>
                    <td><? echo "<input class='ns2 majorfont' type='text' name='elemyr' maxlength='4' size='15'>"; ?></td>
                </tr>
                <tr>
                    <td class="majorfont">High School: </td>
                   <td><? echo "<input class='ns1 majorfont' type='text' name='highname' maxlength='100' size='25'>"; ?></td>
                    <td><? echo "<input class='ns1 majorfont' type='text' name='highmadd' maxlength='100' size='25'>"; ?></td>
                    <td><? echo "<input class='ns2 majorfont' type='text' name='highyr' maxlength='4' size='15'>"; ?></td>
                </tr>
                <tr>
                    <td class="majorfont">College:</td>
                    <td><? echo "<input class='ns1 majorfont' type='text' name='colname' maxlength='100' size='25'>"; ?></td>
                    <td><? echo "<input class='ns1 majorfont' type='text' name='colmadd' maxlength='100' size='25'>"; ?></td>
                    <td><? echo "<input class='ns2 majorfont' type='text' name='colmyr' maxlength='4' size='15'>"; ?></td>
                </tr>
                 <tr> 
                    <td class="majorfont">Course:</td>
                    <td><? echo "<input class='ns1 majorfont' type='text' name='corsname' maxlength='100' size='30'>"; ?></td>
                    
                </tr>
            </table>
            <table>
                            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
                <tr> 
                    <td><div class='fontba1'>Work Experience</div><td>
                </tr>
                <tr>
                    <td><textarea name="wexp" class="trea1 majorfont"></textarea></td>
                </tr>
            </table>
        
        
        <table>
                <tr> 
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
                    <td><div class='fontba1'>Training and Seminars</div><td>
                </tr>
               
                <tr>
                    <td><textarea name="sem" class="trea1 majorfont"></textarea></td>
                </tr>
        </table>
        <table>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
                <tr> 
                    <td><div class='fontba1'>Field of Skills</div><td>
                </tr>
                <tr>
                    <td><textarea name="fos" class="trea1 majorfont"></textarea></td>
                </tr>
            </table>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />             
            <div class='fontba1'>Character Reference</div>
            <table border="1px" class='flot1 flot2'>
                
                <tr class="majorfont textcenter">
                    <td>Name: </td>
                    <td>Address: </td>
                    <td>Position: </td>
                    <td>Contact Number: </td>
                </tr>
                <tr class="majorfont">
                    <td><? echo "<input class='cf1 majorfont' type='text' name='cr1a' maxlength='50' size='30'>"; ?></td>
                    <td><? echo "<input class='cf2 majorfont' type='text' name='cr1b' maxlength='100' size='30'>"; ?></td>
                    <td><? echo "<input class='cf2 majorfont' type='text' name='cr1c' maxlength='20' size='30'>"; ?></td>
                    <td><? echo "<input class='cf2 majorfont' type='text' name='cr1d' maxlength='11' size='30' >"; ?></td>
                </tr>
                <tr class="majorfont">
                    <td><? echo "<input class='cf1 majorfont' type='text' name='cr2a' maxlength='50' size='30'>"; ?></td>
                    <td><? echo "<input class='cf2 majorfont' type='text' name='cr2b' maxlength='100' size='30'>"; ?></td>
                    <td><? echo "<input class='cf2 majorfont' type='text' name='cr2c' maxlength='20' size='30'>"; ?></td>
                    <td><? echo "<input class='cf2 majorfont' type='text' name='cr2d' maxlength='11' size='30' >"; ?></td>
                </tr>
                <tr class="majorfont">
                    <td><? echo "<input class='cf1 majorfont' type='text' name='cr3a' maxlength='50' size='30'>"; ?></td>
                    <td><? echo "<input class='cf2 majorfont' type='text' name='cr3b' maxlength='100' size='30'>"; ?></td>
                    <td><? echo "<input class='cf2 majorfont' type='text' name='cr3c' maxlength='20' size='30'>"; ?></td>
                    <td><? echo "<input class='cf2 majorfont' type='text' name='cr3d' maxlength='11' size='30'  >"; ?></td>
                </tr>
            </table>

          <?
        echo "<form action='viewResume.php' method='POST'>\n
        <input class='majorfont buttonsize' type='submit' value='Submit'>\n";
        ?>
        
            <div class='bac'>
                <div class='bac1'></div>
                <div class='reserv majorfont'>All Rights Reserved.2014 <br />Powered by: XAMPP <br /> Ronald S.Domingo <br />BSIT-3</div>
                <div class='bacA'></div>
        
            </div>
         </div>
             </form>
    </body>
</html>
